clc,clear all;

% Question-2

% (a) Random Bit Generation
function bit_sequence = generateBits(num_bits)
    bit_sequence = randi([0 1], 1, num_bits); 
end

% (b) BPSK Mapping
function modulated_signal = modulateBPSK(bit_sequence)
    % Maps 0 -> +1, 1 -> -1
    modulated_signal = 1 - 2 * bit_sequence;
end

% (c) BPSK Symbol Generation
num_samples = 12000;
data_bits = generateBits(num_samples);
% Map bits to BPSK symbols
bpsk_modulated = modulateBPSK(data_bits); 

% (d) Adding AWGN (Noise)
SNR_dB = 0:30; 
SNR_linear = 10.^(SNR_dB/10); 
BER_results = zeros(size(SNR_linear)); 

for idx = 1:length(SNR_linear)
    noise_power = 1 ./ SNR_linear(idx); 
    noise_stddev = sqrt(noise_power / 2); 
    noise_signal = noise_stddev * (randn(1, num_samples) + 1j * randn(1, num_samples)); 
    received_signal = bpsk_modulated + noise_signal; 
    detected_bits = real(received_signal) < 0; 
    BER_results(idx) = sum(detected_bits ~= data_bits) / num_samples; 
end

% (e) Ideal Bit Error Probability Plot
function Q_value = Q_func(x)
    Q_value = 0.5 * erfc(x / sqrt(2));
end

% Q-function for theoretical BER
BER_theory = Q_func(sqrt(2 * SNR_linear)); 

figure;
semilogy(SNR_dB, BER_theory, 'r-', 'LineWidth', 2); hold on;
semilogy(SNR_dB, BER_results, 'Color', [0 0.5 0], 'Marker', '*', 'LineWidth', 2);
grid on;
legend('Theoretical BER (Red)', 'Simulated BER (Dark Green)');
xlabel('E_b/N_0 (dB)'); ylabel('Bit Error Rate (BER)');
title('BPSK Bit Error Rate vs. E_b/N_0');

% Ensure BER_theory is strictly decreasing
[unique_BER, indices] = unique(BER_theory, 'stable');
SNR_dB_unique = SNR_dB(indices);

% Perform interpolation with unique values
target_BERs = [1e-2, 1e-5];
interpolated_SNR = interp1(unique_BER, SNR_dB_unique, target_BERs, 'linear', 'extrap');

disp(['E_b/N_0 for BER=10^-2: ', num2str(interpolated_SNR(1)), ' dB']);
disp(['E_b/N_0 for BER=10^-5: ', num2str(interpolated_SNR(2)), ' dB']);