function symbols = map_bpsk(input_bits)
    % BPSK modulation
    symbols = 1 - 2 * input_bits;
end

function symbols = map_qpsk(input_bits)
    % QPSK modulation using Gray coding
    gray_mapping = [1+1j, -1+1j, -1-1j, 1-1j];
    idx = bi2de(reshape(input_bits, [], 2), 'left-msb') + 1;
    symbols = gray_mapping(idx);
end

function symbols = map_4pam(input_bits)
    % 4-PAM modulation using Gray coding
    gray_mapping = [-3, -1, 1, 3];
    idx = bi2de(reshape(input_bits, [], 2), 'left-msb') + 1;
    symbols = gray_mapping(idx);
end

function symbols = map_16qam(input_bits)
    % 16-QAM modulation using Gray coding
    gray_mapping = [-3, -1, 1, 3];
    input_bits = reshape(input_bits, [], 4);
    real_part = gray_mapping(bi2de(input_bits(:, 1:2), 'left-msb') + 1);
    imag_part = gray_mapping(bi2de(input_bits(:, 3:4), 'left-msb') + 1);
    symbols = real_part + 1j * imag_part;
end

function symbols = map_8psk(input_bits)
    % 8-PSK modulation using Gray coding
    phase_values = [0, 1, 3, 2, 6, 7, 5, 4] * pi / 4;
    idx = bi2de(reshape(input_bits, [], 3), 'left-msb') + 1;
    symbols = exp(1j * phase_values(idx));
end

% === Plotting Modulation Schemes ===
figure;

subplot(2,3,1);
bpsk_bits = [0; 1];
scatter(real(map_bpsk(bpsk_bits)), imag(map_bpsk(bpsk_bits)), 'o');
grid on;
title('BPSK'); xlabel('In-Phase'); ylabel('Quadrature');

subplot(2,3,2);
qpsk_bits = [0 0; 0 1; 1 1; 1 0];
scatter(real(map_qpsk(qpsk_bits)), imag(map_qpsk(qpsk_bits)), 'o');
grid on;
title('QPSK'); xlabel('In-Phase'); ylabel('Quadrature');

subplot(2,3,3);
fourpam_bits = [0 0; 0 1; 1 1; 1 0];
stem(map_4pam(fourpam_bits), zeros(size(map_4pam(fourpam_bits))), 'o');
grid on;
title('4-PAM'); xlabel('In-phase'); ylabel('');

subplot(2,3,4);
sixteenqam_bits = [
    0 0 0 0;
    0 0 0 1;
    0 0 1 0;
    0 0 1 1;
    0 1 0 0;
    0 1 0 1;
    0 1 1 0;
    0 1 1 1;
    1 0 0 0;
    1 0 0 1;
    1 0 1 0;
    1 0 1 1;
    1 1 0 0;
    1 1 0 1;
    1 1 1 0;
    1 1 1 1
];
scatter(real(map_16qam(sixteenqam_bits)), imag(map_16qam(sixteenqam_bits)), 'o');
grid on;
title('16-QAM'); xlabel('In-Phase'); ylabel('Quadrature');

subplot(2,3,5);
eightpsk_bits = [
    0 0 0;
    0 0 1;
    0 1 1;
    0 1 0;
    1 1 0;
    1 1 1;
    1 0 1;
    1 0 0
];
scatter(real(map_8psk(eightpsk_bits)), imag(map_8psk(eightpsk_bits)), 'o');
grid on;
title('8-PSK'); xlabel('In-Phase'); ylabel('Quadrature');